package com.example.talentchat;

public class button {

    String category_tag;
    int category_image;

    public button(String category_tag, int category_image) {
        this.category_tag = category_tag;
        this.category_image = category_image;
    }
}

